import 'bootstrap/dist/css/bootstrap'
import './styles/style.css'
import { Game } from "./Game";

const d = new Game();
